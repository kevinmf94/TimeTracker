package cat.uab.ds.core.entity;

/**
 * Class contains configuration variables
 */
public class Configuration {
    public static int MIN_TIME = 1;//Minimun time in Seconds
    public static int SEC_TO_MILIS = 1000;
}
