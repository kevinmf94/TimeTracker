package cat.uab.ds;

class MainApplication {

}
